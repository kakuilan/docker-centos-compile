---
name: Bug report
about: I want to report a Bug
title: ''
labels: bug
assignees: ''

---

## Bug Report

Please answer these questions before submitting your issue. Thanks!

1. What did you do? If possible, provide a simple script for reproducing the error.


2. What did you expect to see?


3. What did you see instead


4. What is your Xhprof version?
